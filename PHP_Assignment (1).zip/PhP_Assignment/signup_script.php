<?php
    require "./includes/common.php";
    $email = mysqli_real_escape_string($c, $_POST["email"]);
    $name = mysqli_real_escape_string($c, $_POST["name"]);
    $password = mysqli_real_escape_string($c, $_POST["password"]);
    $contact = mysqli_real_escape_string($c, $_POST["contact"]);
    $city = mysqli_real_escape_string($c, $_POST["city"]);
    $address = mysqli_real_escape_string($c, $_POST["address"]);
    $coded_password = md5(md5($password));
    $query1 = "SELECT id FROM users WHERE email = '$email' AND password = '$coded_password'";
    $query1 = "INSERT INTO users (name, email, password, contact, city, address) VALUES ('$name', '$email', '$coded_password', '$contact', '$city', '$address')";
    $result = mysqli_query($c, $query1);
    
    if(mysqli_num_rows($result) > 0)
    {
        // email already exists
        echo "Email id already exists. Try another";
    }
    
    else
    {
       
        $result = mysqli_query($c, $query2);
        $_SESSION["email_id"] = $email;
        $_SESSION["id"] = mysqli_insert_id($c);
        header("location: products.php");
    }
?>

