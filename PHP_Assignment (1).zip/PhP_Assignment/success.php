<?php
    require './includes/common.php';
    if(!isset($_SESSION['email']))
    {
        header("location: index.php");
    }
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Success</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css.css"/>
    <body>
        <?php
            require './includes/header.php';
            $user_id = $_SESSION["id"];
            $query = "SELECT item_id FROM users_items WHERE user_id = '$user_id'";
            $result = mysqli_query($c, $query) or die(mysqli_error($c));
            
            while($row = mysqli_fetch_array($result)){
                $item_id = $row["item_id"];
                $query1 = "UPDATE users_items SET status = 'Confirmed' WHERE item_id = '$item_id'";
                $result1 = mysqli_query($c, $query1) or die(mysqli_error($c));
            }
        ?>
        <div class="container" style="padding: 75px 75px 75px 75px; font-size: 15px;">
            Your Order is confirmed. Thank you for shopping with us.
            <br> <a href="products.php">Click here</a> to purchase any other item.
        </div>
        <?php
         require './includes/footer.php';
        ?>
    </body>
</html>