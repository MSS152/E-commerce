<?php
    require './includes/common.php';
    if(!isset($_SESSION["email"])){
        header("location: login.php");
    }
    else{
        
        $user_id = $_SESSION["id"];
        $email = $_SESSION["email"];
        $newpwd = md5(md5(mysqli_real_escape_string($c, $_POST["newpwd"])));
        $repwd = md5(md5(mysqli_real_escape_string($c, $_POST["repwd"])));

        if(strlen($newpwd) != strlen($repwd)){
            echo "ERROR. Try again.";
        }else{
            $query = "UPDATE users SET password = '$newpwd' WHERE email = '$email' AND id = '$user_id'";

            $result = mysqli_query($c, $query) or die(mysqli_error($c));

            header("location: settings.php");
        }
?>
